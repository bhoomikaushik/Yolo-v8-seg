# segmentation cars > 2023-11-18 8:43pm
https://universe.roboflow.com/deep-u7mqx/segmentation-cars

Provided by a Roboflow user
License: CC BY 4.0

